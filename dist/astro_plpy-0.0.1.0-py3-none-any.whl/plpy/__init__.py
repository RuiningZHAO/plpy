"""
Data reduction pipelines developed based on drpy.
"""

__version__ = '0.0.1.0'